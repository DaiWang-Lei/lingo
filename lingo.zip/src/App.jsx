import { useState } from "react";
import {
  Cube,
  Model,
  Mouse,
  OrbitCamera,
  Skybox,
  ThirdPersonCamera,
  useKeyboard,
  useLoop,
  useMouse,
  World,
} from "lingo3d-react";
import logo from "./logo.svg";
import "./App.css";
import { useRef } from "react";

function App() {
  const [walking, setWalking] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0, z: 0 });
  const narutoRef = useRef();
  const handleClick = (e) => {
    e.point.y = 0;
    setPosition(e.point);
    setWalking(true);
    const model = narutoRef.current;
    model.lookAt(e.point);
  };

  const handleIntersect = () => {
    setWalking(false);
  };
  const key = useKeyboard();
  let model = narutoRef.current;

  useLoop(() => {
    model.moveForward(-10);
  }, key === "w");

  useLoop(() => {
    model.moveRight(10);
  }, key === "a");
  useLoop(() => {
    model.moveRight(-10);
  }, key === "d");
  useLoop(() => {
    model.moveForward(5);
  }, key === "s");
  const action =
    key === "w" || key === "a" || key === "d" || key === "s"
      ? "walking"
      : "idle";
  const createWind = () => {};
const winds = [<Cube/>]
  return (
    <World>
      <Skybox
        texture={[
          "Left.png",
          "Right.png",
          "Up.png",
          "Down.png",
          "Front.png",
          "Back.png",
        ]}
      />
      {/* <Cube
        onClick={handleClick}
        width={9999}
        depth={9999}
        y={-100}
        // opacity={ }
      /> */}

      {/* <OrbitCamera active z={300} /> */}
      {/* <Cube
        id="orangeBox"
        scale={0.5}
        color="orange"
        x={position.x}
        y={position.y}
        z={position.z}
        opacity={0}
      /> */}
      {/* <Model
        src="yile.fbx"
        scale={6}
        x={-1300}
        z={200}
        y={-900}
        physics={"map"}
      /> */}
           {/* <Model
          src="ichigoskin.fbx"
          // scale={1}
          physics={"map"}
          scale={10}
          x={-900}
          y={-600}
        /> */}
      <Model src="ship.glb" scale={100} y={-100} physics={'map'} />

      <ThirdPersonCamera active mouseControl>
        <Model
          ref={narutoRef}
          src="Naruto.fbx"
          animations={{ idle: "Idle.fbx", walking: "Running.fbx" }}
          animation={action}
          intersectIDs={["orangeBox"]}
          onIntersect={handleIntersect}
          scale={3}
          physics={"character"}
        />
      </ThirdPersonCamera>

      <Mouse onClick={createWind} />
 
    </World>
  );
}

export default App;
